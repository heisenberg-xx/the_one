# Mascot behaviour script

**Load.** He sleeps stretched along the top of RAJESH, breathing slowly, "z z z" rising from his head. Click him: he stirs, sits up, waves "Hey! 👋", and settles back to sleep.

**First scroll down.** He wakes, pulls on a dark hood and a domino mask, and springs off the heading. Mid-air he fires a silk line back to the end of "RAJESH", swings down in a long arc, and ends up hanging beside the About text on a line from the top of the section.

**Into Experience.** He lets go, drops onto the timeline bar, lands with a crouch, then rolls underneath and crawls along its underside, upside-down, back and forth.

**Into Skills.** He drops from the bar, pulls off the mask, snaps on lab goggles and a leather apron, and lands on a skill card next to a small bench of glowing flasks that bubble while he works.

**Into Works.** Goggles and apron off, a black fedora on. He hops onto the "Works" heading and stands there, proud.

**Scrolling up, or jumping around.** A jet helmet with an amber visor slit closes over his head, thrusters ignite in his palms and boots, and he flies to wherever the visitor stopped — then lands, changes into that section's outfit and picks up its act. Reach the top and he lands on RAJESH, takes the helmet off, and falls asleep again.
