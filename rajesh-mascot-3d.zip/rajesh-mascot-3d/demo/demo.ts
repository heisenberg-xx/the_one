import { MascotStage } from "../components/mascot3d/core/stage";
import { Director } from "../components/mascot3d/core/director";
import { defaultStations } from "../components/mascot3d/core/stations";

(async () => {
  const params = new URLSearchParams(location.search);
  const modelUrl = params.get("model") ?? "./rajesh.glb";
  const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const size = innerWidth < 768 ? 170 : 260;
  const box = document.getElementById("mascot-box")!;
  const host = document.getElementById("mascot-host")!;
  const line = document.getElementById("mascot-line") as unknown as SVGLineElement;
  const bubble = document.getElementById("mascot-bubble")!;
  const zzz = document.getElementById("mascot-zzz")!;
  const status = document.getElementById("status")!;
  box.style.width = box.style.height = `${size}px`;
  const stage = new MascotStage(host);
  stage.setReducedMotion(reduced);
  try {
    const { clips } = await stage.load({ modelUrl });
    (window as any).__clips = clips;
    (window as any).__stage = stage;
  } catch (e) {
    status.textContent = `Couldn't load ${modelUrl}. Put your rigged GLB next to this file as rajesh.glb, or open with ?model=path/to/file.glb`;
    status.hidden = false;
    return;
  }
  const dir = new Director(stage, defaultStations(), {
    box, line, zzz, bubble,
    say: (t) => { bubble.textContent = t ?? ""; bubble.style.opacity = t ? "1" : "0"; },
    onState: (s) => { document.body.dataset.at = s.at; document.body.dataset.busy = String(s.busy); document.body.dataset.outfit = s.outfit; },
  }, { size, reduced });
  await dir.begin();
  box.style.opacity = "1";
  document.getElementById("mascot-hit")!.addEventListener("click", () => void dir.greet());
  (window as any).__ready = true;
})();
