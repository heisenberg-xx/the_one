# One-character 3D mascot — Claude Code handoff

Claude Code: this folder is a complete, tested drop-in for the Rajesh Ande portfolio (Next.js + TypeScript + Tailwind). Follow the steps in order and report back at the end.

## What it does

A single rigged 3D character travels the whole page, driven by scroll:

1. **Hero:** sleeps on top of the real HTML word "RAJESH", "z z z" drifting up. Click (or Tab + Enter) → wakes, waves "Hey! 👋", sleeps again.
2. **First scroll down:** wakes, hood + domino mask on, jumps off, shoots a silk line back to the end of "RAJESH" and swings down into About, where he hangs on a line beside the text.
3. **Experience:** lets go, lands on the timeline bar, rolls underneath and crawls back and forth upside-down.
4. **Skills:** drops off the bar, mask off, lab goggles + apron on, lands on a skill card and "cooks" at a small bench of glowing, bubbling flasks.
5. **Works:** gear off, fedora on, hops onto the "Works" heading text and holds a proud pose.
6. **Scrolling up, skipping sections, or uneven scrolling:** jet helmet on, palm and boot thrusters fire, he flies to wherever the visitor settled, lands, changes into that section's outfit and plays its act. At the top he lands on "RAJESH" and goes back to sleep.

Continuous, steady scrolling down plays the scripted beats in order; anything else becomes a flight once scrolling settles (~0.25 s).

## Files in this folder

```text
components/mascot3d/
├── core/
│   ├── config.ts        acts, outfits, clip-name candidates, defaults
│   ├── stage.ts         three.js scene: loads the GLB, plays clips, swaps outfits, lights
│   ├── accessories.ts   built-in original accessories attached to bones (used if the GLB has no acc_* nodes)
│   ├── director.ts      the scroll script: stations, beats, flight, silk line, zzz, bubble
│   └── stations.ts      where each station is on the page (data-mascot-spot markers)
├── PortfolioMascot.tsx  React wrapper, mount once
├── useReducedMotion.ts
└── index.ts
scripts/
├── inspect-glb.mjs      lists clips → acts, bones, accessory nodes, size
├── blender_fbx_to_glb.py  Mixamo FBX → GLB (headless Blender)
└── optimize-glb.sh      meshopt + WebP textures
public/mascot/README.md  what goes in public/mascot
demo/                    standalone preview harness (same core), see "Preview without Next.js"
MODEL_PIPELINE.md        how Rajesh makes rajesh.glb from his character sheet
MASCOT_SCRIPT.md         the behaviour script
```

## Steps

1. **Inspect** `package.json` (Next/React versions), `tsconfig.json` (confirm the `@/*` alias), and the real section files: `HeroSection.tsx`, `About.tsx`, `Experience.tsx`, `Skills.tsx`, `Works.tsx`, and the `Home` page.
2. **Remove the earlier 2D mascot if it was integrated** (`components/mascot/`, `<HeroMascot>`, `<SectionMascot>`, `<FlyingMascot>`, `data-mascot-*` attributes other than `data-mascot-spot`, `scripts/render-mascot-sprites.mjs`, `public/mascot/sprites`). There must be only one character.
3. **Copy** `components/mascot3d/` and `scripts/` into the repo as-is. Copy `public/mascot/README.md` to `public/mascot/`.
4. **Install:** `npm i three` and `npm i -D @types/three`. Use matching versions (e.g. `three@0.170` with `@types/three@0.170`); the code uses only stable APIs (GLTFLoader, MeshoptDecoder, AnimationMixer).
5. **Mark the page** (attributes only, no layout changes):
   - Hero: `<span data-mascot-spot="hero">Rajesh</span> Ande` inside the existing `<h2>`.
   - About: `data-mascot-spot="about"` on the text container (the `div` holding the paragraphs).
   - Experience: `data-mascot-spot="experience"` on the desktop horizontal bar `motion.div`. For mobile (vertical timeline), put the same attribute on the **first milestone card** of the mobile list instead of the vertical bar — he crawls under whichever marked element is visible.
   - Skills: `data-mascot-spot="skills"` on one card in the first visible row (prefer the second card). He stands on its top edge, so leave ~180 px free above it.
   - Works: wrap the heading word in `<span data-mascot-spot="projects">…</span>` (the "Works" text). He stands on its top edge.
6. **Mount once** at the end of `<main>` in the Home page: `import { PortfolioMascot } from "@/components/mascot3d";` → `<PortfolioMascot />`. It is a client component that lazy-loads three.js after first paint.
7. **Model:** if `public/mascot/rajesh.glb` doesn't exist yet, download a Mixamo-rigged stand-in for testing and pass it in:
   ```bash
   curl -L -o public/mascot/test-soldier.glb https://raw.githubusercontent.com/mrdoob/three.js/r170/examples/models/gltf/Soldier.glb
   ```
   `<PortfolioMascot modelUrl="/mascot/test-soldier.glb" debug />` — remove both props once `rajesh.glb` is in place. Do not commit the stand-in.
8. **When Rajesh's model arrives**, run `node scripts/inspect-glb.mjs public/mascot/rajesh.glb`. For each act showing "none", either edit `CLIP_CANDIDATES` in `core/config.ts` to match his clip names, or pass separate clip files: `<PortfolioMascot animationUrls={{ sleep: "/mascot/anims/sleeping-idle.glb", … }} />`. Then tune `facing` per station in `core/stations.ts` so each pose reads well (yaw degrees: 0 faces the visitor, 90 faces right). If the fly clip is already horizontal, pass `flyPose="horizontal"`.
9. Run `npx tsc --noEmit`, `npm run lint`, `npm run dev`, and verify the checklist below.

## Verify

- Hero: he rests on the cap tops of RAJESH. If he floats/sinks, change the `0.14` in the hero `ground()` in `core/stations.ts`. The heading stays real, selectable text.
- Click and keyboard wake/greet work only while he sleeps on the hero.
- Slow scroll down: hero → About swing (silk line drawn from his hand to "RAJESH", then to the top of About) → Experience crawl → Skills cook → Works proud.
- Jump with the navbar from Works to About, or scroll up: jet flight, then the About act. Scroll to the very top: flight back, sleep.
- Reduced motion (DevTools → Rendering): no travelling or flights; he appears in each station's pose.
- Mobile width: experience uses the marked mobile card; no horizontal scrollbar; overlay never blocks clicks (only the sleeping hit-area is clickable).
- If the model fails to load, `/mascot/poster-sleep.png` (when present) sits on RAJESH instead.

## Preview without Next.js

`demo/index.html` is the same core bundled with a mock of the portfolio. Serve the folder (`npx serve demo`) with a model next to it as `rajesh.glb`, or open `index.html?model=path/to/model.glb`. To rebuild after editing the core: `npx esbuild demo/demo.ts --bundle --format=iife --minify --outfile=demo/demo.js` and paste into `template.html` where `/*BUNDLE*/` is (or load `demo.js` with a script tag).

## Report back

What you changed in each file, which elements got `data-mascot-spot`, the output of `inspect-glb.mjs`, and any act still using a fallback clip.
