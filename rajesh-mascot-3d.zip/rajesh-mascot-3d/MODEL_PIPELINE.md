# Making rajesh.glb from the character sheet

The wardrobe sheet is a 2D concept image. The mascot needs a **rigged 3D model** (a skeleton inside the mesh) plus animation clips. This is the shortest reliable route.

## 1. Base character (default developer outfit)

- Use the sheet's *Turnaround (base model)* views — front, side, back — as input to an image-to-3D tool (for example Meshy, Tripo or Rodin; check which currently offers character/A-pose output).
- Ask for a single humanoid in an A-pose or T-pose, arms away from the body, hands open, hoodie + cargo pants + sneakers.
- Target 20–40k triangles and one 2K texture. Export FBX or OBJ.
- Check the face and beard read well from 3 m away; that's the scale people see.

## 2. Rig it (Mixamo)

- Upload to mixamo.com, place the auto-rigger markers (chin, wrists, elbows, knees, groin), let it rig.
- Download the character **FBX, With Skin, T-pose** → `rajesh.fbx`.

## 3. Animations (Mixamo, same character)

For each clip: **FBX, Without Skin**, tick **In Place** where offered, 30 fps. Save each with the file name on the left so the code matches it automatically.

| File name | Act | What to search in Mixamo |
|---|---|---|
| sleeping-idle | sleep | lying / sleeping idle |
| getting-up | wake | getting up / waking |
| waving | greet | waving |
| jump | jump, takeoff | jump |
| hanging-idle | hang, swing | hanging idle |
| falling-idle | fall | falling idle |
| hard-landing | land, touchdown | hard landing / falling to landing |
| crawling | crawl | crawling |
| typing | cook | typing / mixing / stirring (anything with hands at a bench) |
| victory-idle | proud | victory idle / standing arms crossed |
| walking | walk | walking |
| flying | fly | flying |
| idle | idle | breathing idle |

Clip names vary; `node scripts/inspect-glb.mjs` shows how each act resolves, and `CLIP_CANDIDATES` in `core/config.ts` is easy to edit.

## 4. Convert to GLB

```bash
blender -b -P scripts/blender_fbx_to_glb.py -- ./mixamo-fbx ./public/mascot/anims
mv public/mascot/anims/rajesh.glb public/mascot/rajesh.glb
```

Either keep clips as separate files and pass `animationUrls`, or merge them into `rajesh.glb` in Blender (NLA → push down each action, export with "Animations: NLA tracks").

## 5. Outfits

Out of the box, the code adds its own original accessories to the bones: hood, domino mask, lab goggles, leather apron, lab bench with flasks, fedora, jet helmet with an amber visor slit, and palm/boot thrusters.

To use your own pieces from the sheet's inventory instead, model them in Blender, parent each to the right bone (head, spine, hands, feet), and name the top object:

`acc_hood`, `acc_domino`, `acc_goggles`, `acc_apron`, `acc_lab`, `acc_fedora`, `acc_jethelmet`, `acc_thrusters`

When any `acc_*` node exists, the built-in accessories switch off. Leave out the sheet's full armour suit and helmet faceplate and the hat-and-sunglasses coat look; the plain jet helmet and the fedora are what the script uses.

## 6. Optimise

```bash
scripts/optimize-glb.sh public/mascot/rajesh.glb public/mascot/rajesh.opt.glb
```

Aim for under ~5 MB total. Rename the optimised file to `rajesh.glb`.

## 7. Poster fallback

Crop the sleeping frame from the sheet's *Sleep (Hero)* row onto a transparent PNG → `public/mascot/poster-sleep.png`. It's shown on RAJESH if WebGL or the model fails.
